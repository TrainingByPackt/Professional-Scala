package com.packt.courseware.l4

class ConstructorChainParent(a:String)

class ConstructorChain(a:String) extends ConstructorChainParent(a)


 Day2/ Lesson3/ Part1

   Make effects parameter implicit.

 (TODO: create students version).


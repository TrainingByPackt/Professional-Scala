
 1:  rewrite Remind/Store Chatbot mode using Map.
   (change RemindeState to Map)  

 

Assessment:  (30 min):  add a simple TODO list to our chatbot, use Vector 

It should understand next command:

  todo list -- output list of todos-s which are not done.
  todo new text  --  store text as todo. (output numebr as answer)
  todo done text (or number) --  mark item as done.

new and done commands should return answers, started from "ok" in case of successful evaluation.



